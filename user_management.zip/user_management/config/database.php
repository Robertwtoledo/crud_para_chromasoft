<?php
$host = 'localhost';
$dbname = 'sistema_cadastro';  // Nome do banco de dados
$username = 'root';  // Usuário padrão do MySQL no XAMPP
$password = '';  // Senha padrão no XAMPP (deixe em branco)

try {
    // Criação da conexão com o banco de dados
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Configuração do PDO para exibir erros
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Erro de conexão: ' . $e->getMessage();
}
?>
