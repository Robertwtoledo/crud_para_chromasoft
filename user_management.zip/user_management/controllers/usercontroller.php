<?php
require_once '../config/database.php';
require_once '../models/User.php';

$userModel = new User($pdo);

// Rota para listagem de usuários (GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Obtém todos os usuários
        $stmt = $pdo->prepare("SELECT * FROM usuarios");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($users);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Erro ao listar os usuários: ' . $e->getMessage()]);
    }
}

// Rota para criação de usuário (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebe os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    try {
        // Verifica se o e-mail já está cadastrado
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingUser) {
            echo json_encode(['error' => 'Este e-mail já está cadastrado.']);
        } else {
            // Cria o novo usuário
            $userModel->create($nome, $email, $senha);
            echo json_encode(['success' => 'Usuário cadastrado com sucesso!']);
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Erro ao cadastrar o usuário: ' . $e->getMessage()]);
    }
}

// Rota para atualização de usuário (PUT)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Obtém os dados do corpo da requisição
    parse_str(file_get_contents("php://input"), $_PUT);
    $id = $_PUT['id'];
    $nome = $_PUT['nome'];
    $email = $_PUT['email'];
    $senha = $_PUT['senha'] ?? null;

    try {
        // Atualiza os dados do usuário
        $userModel->update($id, $nome, $email, $senha);
        echo json_encode(['success' => 'Usuário atualizado com sucesso!']);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Erro ao atualizar o usuário: ' . $e->getMessage()]);
    }
}

// Rota para exclusão de usuário (DELETE)
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Obtém os dados do corpo da requisição
    parse_str(file_get_contents("php://input"), $_DELETE);
    $id = $_DELETE['id'];

    try {
        // Exclui o usuário
        $userModel->delete($id);
        echo json_encode(['success' => 'Usuário excluído com sucesso!']);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Erro ao excluir o usuário: ' . $e->getMessage()]);
    }
}
?>
