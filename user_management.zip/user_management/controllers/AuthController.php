<?php
require_once '../config/database.php';
require_once '../models/User.php';

session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$userModel = new User($pdo);

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && $_SESSION['csrf_token'] === $token;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        echo json_encode(['error' => 'Token CSRF inválido.']);
        exit;
    }

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    try {
        $user = $userModel->login($email, $senha);

        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nome'] = $user['nome'];
            echo json_encode(['success' => 'Login realizado com sucesso!']);
        } else {
            echo json_encode(['error' => 'E-mail ou senha incorretos.']);
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Erro ao realizar o login: ' . $e->getMessage()]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['logout'])) {
    session_destroy();
    echo json_encode(['success' => 'Logout realizado com sucesso!']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['check_login'])) {
    if (isset($_SESSION['user_id'])) {
        echo json_encode(['success' => 'Usuário está logado.', 'user_id' => $_SESSION['user_id'], 'user_nome' => $_SESSION['user_nome']]);
    } else {
        echo json_encode(['error' => 'Usuário não está logado.']);
    }
}
?>
