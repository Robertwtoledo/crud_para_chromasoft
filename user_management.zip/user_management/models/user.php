<?php
class User {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Cria um novo usuário
    public function create($nome, $email, $senha) {
        // Criptografando a senha
        $hashedPassword = password_hash($senha, PASSWORD_BCRYPT);
        $stmt = $this->pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
        $stmt->execute([$nome, $email, $hashedPassword]);
    }

    // Atualiza os dados de um usuário
    public function update($id, $nome, $email, $senha = null) {
        if ($senha) {
            $hashedPassword = password_hash($senha, PASSWORD_BCRYPT);
            $stmt = $this->pdo->prepare("UPDATE usuarios SET nome = ?, email = ?, senha = ? WHERE id = ?");
            $stmt->execute([$nome, $email, $hashedPassword, $id]);
        } else {
            $stmt = $this->pdo->prepare("UPDATE usuarios SET nome = ?, email = ? WHERE id = ?");
            $stmt->execute([$nome, $email, $id]);
        }
    }

    // Exclui um usuário
    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->execute([$id]);
    }

    // Obtém todos os usuários
    public function getAll() {
        $stmt = $this->pdo->prepare("SELECT * FROM usuarios");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
